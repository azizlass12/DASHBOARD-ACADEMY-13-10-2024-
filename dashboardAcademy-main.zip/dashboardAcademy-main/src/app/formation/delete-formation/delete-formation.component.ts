import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-delete-formation',
  templateUrl: './delete-formation.component.html',
  styleUrls: ['./delete-formation.component.css']
})
export class DeleteFormationComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
