import { Component, OnInit } from '@angular/core';


import { FormationService } from '../formation.service';

@Component({
  selector: 'app-liste-formation',
  templateUrl: './liste-formation.component.html',
  styleUrls: ['./liste-formation.component.css']
})



export class  ListeFormationComponent implements OnInit {
  formations: any[] = [];

  constructor(private fs:FormationService) {}

  ngOnInit(): void {
this.fs.getAllFormations().subscribe ((data:any)=> {
  this.formations=data
  console.log('this is my data ',data)
})
  }
}
