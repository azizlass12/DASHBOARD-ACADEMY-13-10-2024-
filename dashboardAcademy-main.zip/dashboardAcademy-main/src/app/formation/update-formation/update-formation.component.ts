import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-update-formation',
  templateUrl: './update-formation.component.html',
  styleUrls: ['./update-formation.component.css']
})
export class UpdateFormationComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
