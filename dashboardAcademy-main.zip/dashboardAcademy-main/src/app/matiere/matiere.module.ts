import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';

import { MatiereRoutingModule } from './matiere-routing.module';


@NgModule({
  declarations: [],
  imports: [
    CommonModule,
    MatiereRoutingModule
  ]
})
export class MatiereModule { }
