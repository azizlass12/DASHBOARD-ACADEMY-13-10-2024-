import { Component, OnInit } from '@angular/core';
import '@cds/core/icon/register.js';

@Component({
  selector: 'app-sidnav',
  templateUrl: './sidnav.component.html',
  styleUrls: ['./sidnav.component.css']
})
export class SidnavComponent  {

  

}
