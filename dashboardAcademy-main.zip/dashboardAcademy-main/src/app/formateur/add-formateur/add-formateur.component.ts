import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-add-formateur',
  templateUrl: './add-formateur.component.html',
  styleUrls: ['./add-formateur.component.css']
})
export class AddFormateurComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
