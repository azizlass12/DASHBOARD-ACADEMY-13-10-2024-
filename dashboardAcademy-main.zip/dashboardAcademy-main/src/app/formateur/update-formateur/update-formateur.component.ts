import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-update-formateur',
  templateUrl: './update-formateur.component.html',
  styleUrls: ['./update-formateur.component.css']
})
export class UpdateFormateurComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
