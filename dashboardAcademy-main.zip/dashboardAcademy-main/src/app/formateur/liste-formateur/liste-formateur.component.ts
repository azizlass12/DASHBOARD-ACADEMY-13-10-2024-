// import { Component, OnInit } from '@angular/core';
// import { FormateurService } from '../formateur.service';
// @Component({
//   selector: 'app-liste-formateur',
//   templateUrl: './liste-formateur.component.html',
//   styleUrls: ['./liste-formateur.component.css']
// })




// export class  ListeFormateurComponent implements OnInit {
//   formations: any[] = [];

//   constructor(private FormateurService : FormateurService ) {}

//   ngOnInit(): void {
//     this.FormateurService .getAllFormateur().subscribe(
//       data => {
//         this.formations = data;
//       },
//       error => {
//         console.error('Erreur lors du chargement des formations:', error);
//       }
//     );
//   }
// }

