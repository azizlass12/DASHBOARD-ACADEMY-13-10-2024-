import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-delete-formateur',
  templateUrl: './delete-formateur.component.html',
  styleUrls: ['./delete-formateur.component.css']
})
export class DeleteFormateurComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
